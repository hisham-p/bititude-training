function is_string(arr){
if(typeof arr === 'string')
  {
  return true;
  }
else
    {
  return false;
  }
}
console.log(is_string('w3resource')); 
console.log(is_string([1, 2, 4, 0]));
