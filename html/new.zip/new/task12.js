let arr = [ 3, -7, 2 ];
for(let i=0;i<arr.length ;i++)
{
  if(arr[i] < 0)
  {
    console.log('The sign of  ' + arr[i] + '  is -');
  }else{
        console.log('The sign of  ' + arr[i] + '  is +');

  }
}
