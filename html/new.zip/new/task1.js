function array(input)
{
 return Array.isArray(input);
}
console.log(array('w3resource'));
console.log(array([1, 2, 4, 0]));

