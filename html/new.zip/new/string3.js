function string_to_array(string){
 return string.split(' ');
}
console.log(string_to_array("Robin Singh"));
