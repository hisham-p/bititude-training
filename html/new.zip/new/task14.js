let arr = [-5, -2, -6, 0, -1 ];
let arr1 = arr.sort();
console.log(arr1[arr.length -1]);
