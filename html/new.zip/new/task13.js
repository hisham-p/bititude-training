let arr = [0, -1, 4 ];
let arr1 = [];
console.log(arr.sort().reverse());
