function protect_email(input){
  let str = [];
  for(let i=0 ; i < input.length ; i++)
  { str.push(input[i]);}
     for(let i=0 ; i < str.length ; i++)
  {
    if(str[i] === '@')
    {
      str.splice(i-6,6, '.....')
    }
  }return str.join('')
}
console.log(protect_email("robin_singh@example.com"));
